const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const axios = require('axios');

// Route to initialize the database with data from external API
router.get('/initialize', async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    const data = response.data;
    await Transaction.deleteMany();
    await Transaction.insertMany(data);
    res.status(200).json({ message: 'Database initialized with seed data.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to get transactions for a given month, with search and pagination
router.get('/transactions', async (req, res) => {
  try {
    const { month, search = '', page = 1, perPage = 10 } = req.query;

    // Convert month to a date range
    const monthNumber = new Date(`${month} 1, 2020`).getMonth();
    const startDate = new Date(2020, monthNumber, 1);
    const endDate = new Date(2020, monthNumber + 1, 1);

    // Build search query
    const query = { dateOfSale: { $gte: startDate, $lt: endDate } };

    if (search) {
      query.$or = [
        { title: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { price: parseFloat(search) || 0 },
      ];
    }

    const transactions = await Transaction.find(query)
      .skip((page - 1) * perPage)
      .limit(parseInt(perPage));

    res.status(200).json({ transactions });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to get statistics (total sales, sold items, unsold items) for a given month
router.get('/statistics', async (req, res) => {
  try {
    const { month } = req.query;
    if (!month) return res.status(400).json({ error: 'Month is required.' });

    const monthNumber = new Date(`${month} 1, 2020`).getMonth();
    const startDate = new Date(2020, monthNumber, 1);
    const endDate = new Date(2020, monthNumber + 1, 1);

    const totalSaleAmount = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startDate, $lt: endDate } } },
      { $group: { _id: null, total: { $sum: '$price' } } },
    ]);

    const totalSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startDate, $lt: endDate },
      sold: true,
    });

    const totalNotSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startDate, $lt: endDate },
      sold: false,
    });

    res.status(200).json({
      totalSaleAmount: totalSaleAmount[0]?.total || 0,
      totalSoldItems,
      totalNotSoldItems,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to get bar chart data (price ranges and number of items) for a given month
router.get('/barchart', async (req, res) => {
  try {
    const { month } = req.query;
    if (!month) return res.status(400).json({ error: 'Month is required.' });

    const monthNumber = new Date(`${month} 1, 2020`).getMonth();
    const startDate = new Date(2020, monthNumber, 1);
    const endDate = new Date(2020, monthNumber + 1, 1);

    const priceRanges = [
      { min: 0, max: 100 },
      { min: 101, max: 200 },
      { min: 201, max: 300 },
      { min: 301, max: 400 },
      { min: 401, max: 500 },
      { min: 501, max: 600 },
      { min: 601, max: 700 },
      { min: 701, max: 800 },
      { min: 801, max: 900 },
      { min: 901, max: Infinity },
    ];

    const data = await Promise.all(
      priceRanges.map(async (range) => {
        const count = await Transaction.countDocuments({
          dateOfSale: { $gte: startDate, $lt: endDate },
          price: { $gte: range.min, $lte: range.max },
        });
        return {
          range: `${range.min}-${range.max === Infinity ? 'above' : range.max}`,
          count,
        };
      })
    );

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route to get pie chart data (category-wise distribution) for a given month
router.get('/piechart', async (req, res) => {
  try {
    const { month } = req.query;
    if (!month) return res.status(400).json({ error: 'Month is required.' });

    const monthNumber = new Date(`${month} 1, 2020`).getMonth();
    const startDate = new Date(2020, monthNumber, 1);
    const endDate = new Date(2020, monthNumber + 1, 1);

    const data = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startDate, $lt: endDate } } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
    ]);

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
